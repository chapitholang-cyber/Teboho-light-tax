TEBOHO - Taxathon 2026 prototype (demo data only)

FILES
  index.html  Officer / Admin system. (Trader view hides Dashboard and Reports.) Dashboard now shows GREEN (compliant),
              YELLOW (in transition) and RED (at risk) status with a colour guide.
              Theme now matches the Taxathon poster (orange) with the new logo.
  logo/       Teboho logo (SVG + PNG, icon and full wordmark) in the orange Taxathon colours.
  ussd.html   Trader-only USSD phone (dial *1991#, choose English or Sesotho).

STATUS RULES (proposed, confirm with RSL)
  GREEN   3 paid months and up to date. Certificate eligible.
  YELLOW  Registered with 1 to 2 paid months.
  RED     No payment for over 45 days. Officer follow-up needed.

HOW TO RUN
  Open index.html or ussd.html in a browser.

SHARED DATA
  Both pages save into the same browser storage and now MERGE on every save: a save only adds new
  records and never overwrites records made on the other page, so USSD and system records stay together.
  They share data only when opened in the same browser from the same place (same website/origin,
  e.g. python3 -m http.server). Different phones/computers do not share data.

CERTIFICATES
  Certificates page: Generate certificate (eligible traders) or Preview (sample).
  Use Print / Save as PDF to download a branded A4 landscape certificate.

DASHBOARD NUMBERS
  Recorded revenue = total of recorded payments (tax collected). Recorded sales = total sales entered.
  Payment amount auto-fills with the trader tax tier.

TRADER VIEW AND LOCKED RECORDS
  Trader view: the trader signs in with their own Trader ID + registered phone number, then can only
  record sales, pay tax and view the certificate for THEIR OWN record. The payment amount is fixed to
  their monthly tax due. New traders choose "I am new: register".
  USSD: paying tax needs a PIN = last 4 digits of the registered phone number.
  Records are locked: there is no edit or delete for traders, sales or payments, and a confirmation
  appears before saving. Dashboard, Reports and Settings are hidden from traders; Settings
  (sample data / clear data) is Administrator view only.
